/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ag;

import static java.lang.Math.abs;
import java.util.Comparator;
import java.util.Vector;

/**
 *
 * @author domiflorzinha
 */
public class individuo implements Comparable<individuo> {
   public Vector <Integer> ser = new Vector();
   public int nota;
   public Vector <Integer> restante = new Vector();
    public void CriaIndividuo (){
        int i, j=0;  
         // System.out.print("Digimon");
        while (true){
            i=((int)(Math.random()*10));
            Integer r =i;  
            if(!ser.contains(r)){
                j++; 
                ser.add(i);
            }
            if(j==8) break;
          
        }
         nota= this.AvaliaIndividuo();
    }
    
    public void Mostra(){
        for ( int u=0; u<ser.size(); u++){
            System.out.print(ser.get(u));
                System.out.print(" ");
        }
            System.out.println();
            System.out.println(nota);
    }
    
    public int AvaliaIndividuo(){
        int y,q,p;
            y=ser.get(7)+10*ser.get(1)+100*ser.get(2)+1000*ser.get(5)+10000*ser.get(4);
            p=ser.get(3)+ser.get(2)*10+ser.get(1)*100+ser.get(0)*1000;
            q=ser.get(1)+ser.get(6)*10+ser.get(5)*100+ser.get(4)*1000;
            nota=abs(y-(p+q));
            return abs(y-(p+q)); 
    }

    
   
   
   public void Mutacao(){
        int posi=((int)(Math.random()*100));
        Vector <Integer> copia = new Vector();
        for(Integer i=0; i<10; i++){
                if(!ser.contains(i)){
                     copia.add(i);
                }
        }
        if(posi < 15){
            int pos=((int)(Math.random()*8));
            int ps=((int)(Math.random()*2));
            
            ser.set(pos, copia.get(ps));
        }
}
   @Override
    public int compareTo (individuo carro){
        if(carro.nota>this.nota){
            return 1;
        }
        
        if (carro.nota<this.nota){
            return -1;
        }
        return 0;
    }
    public boolean Verifica (Vector<Integer> s){
        Vector <Integer> copia = new Vector();
    for(Integer i=0; i<10; i++){
                
                if(!ser.contains(i)){
                    copia.add(i);
                }
        }
    int h=copia.size(); //System.out.println(h);
   // this.Mostra();
    if (h==2)
        return true;
        return false;
    }
}
