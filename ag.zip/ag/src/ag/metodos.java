/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

/**
 *
 * @author domiflorzinha
 */
public class metodos    {
public List <individuo> populacao = new ArrayList<individuo> ();
public void Criapop (Integer f){
    int t=0;// System.out.print("1!\n");
    while(true){
        individuo o = new individuo();
        o.CriaIndividuo(); 
        this.populacao.add(o);
        t++; 
        if(t==f) break;
    }
}
public void Mostrapop (){
    for ( int i=0;i<populacao.size(); i++){
        populacao.get(i).Mostra();
    }
}
public boolean AvaliaPop (){
        int y=0;
         for(int u=0; u<this.populacao.size(); u++){   
             populacao.get(u).nota=populacao.get(u).AvaliaIndividuo();
             if(populacao.get(u).nota == 0) y++;
         }
         if(y>0) return true;
         return false;
    }

public individuo Torneio(){
    individuo mae;
    int p = populacao.size();
    int o=((int)(Math.random()*p));
    int a=((int)(Math.random()*p));
    int i=((int)(Math.random()*p));
    if ( populacao.get(o).nota >= populacao.get(a).nota  && populacao.get(o).nota >= populacao.get(i).nota ){
         mae=populacao.get(o);
    } 
    else if ( populacao.get(a).nota >= populacao.get(o).nota  && populacao.get(a).nota >= populacao.get(i).nota ){
         mae=populacao.get(a);
    }
    else {
         mae=populacao.get(i);
    } 
    return mae;
}

public void Cruzamento (){
 individuo mae = new individuo ();
 individuo pai = new individuo ();
 mae = this.Torneio();
 while(true){
     pai=this.Torneio();
     if(pai!=mae) break;
 }
 individuo filho = new individuo();
         filho.ser= (Vector<Integer>) mae.ser.clone();
 individuo filha = pai;  
     filha.ser= (Vector<Integer>) pai.ser.clone();
int i=1;

 while(true){
     Integer aux;
     int h = ((int)(Math.random()*8));
     int p=((int)(Math.random()*8));
     aux =filho.ser.get(h);
     filho.ser.set(h, filha.ser.get(p));
     filha.ser.set(p,aux);
     i=1;
     if(filho.Verifica(filho.ser) && filha.Verifica(filha.ser)){
         break;
     }
 }
 
 filho.Mutacao();
 filha.Mutacao();
 
    filho.AvaliaIndividuo();
    filha.AvaliaIndividuo();
    populacao.add(filho);
    populacao.add(filha);

}

public void Reinteracao (){
 Collections.sort(this.populacao);
 int r ;
 r= populacao.size();
 r=r/2;
 r++;

 while(r<populacao.size()){
     populacao.remove(r);
 }

}



}
